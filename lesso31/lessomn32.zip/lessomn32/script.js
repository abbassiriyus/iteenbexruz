
function RenderFile() {
  document.querySelector(".cards").innerHTML =""
  items.map(item=>{
    document.querySelector(".cards").innerHTML +=`<div class="card" style="width: 18rem;">
  <img src="${item.img}">
  <div class="card-body">
    <h5 class="card-title">${item.name}</h5>
    <p class="card-text">${item.description}</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item">${item.price}</li>
    <li class="list-group-item">${item.category}</li>
    <li class="list-group-item">${item.features}</li>
  </ul>
  <button class="btn btn-primary">buy</button>
</div>`
  })
}
RenderFile()

function searchdata() {
  var word = document.querySelector('#srch').value;
  document.querySelector(".cards").innerHTML = ""
items.map(item=>{
if (item.name.includes(word)) {
  document.querySelector(".cards").innerHTML += `<div class="card" style="width: 18rem;">
  <img src="${item.img}">
  <div class="card-body">
    <h5 class="card-title">${item.name}</h5>
    <p class="card-text">${item.description}</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item">${item.price}</li>
    <li class="list-group-item">${item.category}</li>
    <li class="list-group-item">${item.features}</li>
  </ul>
  <button class="btn btn-primary">buy</button>
</div>`
}
})

}